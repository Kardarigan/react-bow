export const Products = [
  {
    title: "قدم زدن روی ماه با انیشتین اثر جاشوا فوئر",
    author: "جاشوا فوئر",
    price: 450000,
    covers: [
      "https://upload.wikimedia.org/wikipedia/en/5/59/Moonwalking_with_einstein.jpg?20190902015140",
    ],
  },
];
